from flask import Flask
from .extensions import login_manager
from .auth.routes import auth   

def create_app():
    app = Flask(__name__)
    app.secret_key = "mysecretkey"  
    login_manager.init_app(app)

    app.register_blueprint(auth)   
    return app
