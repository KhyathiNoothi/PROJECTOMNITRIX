
from flask_login import UserMixin
from .extensions import login_manager

class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password


@login_manager.user_loader
def load_user(user_id):
    return User(user_id, "", "")