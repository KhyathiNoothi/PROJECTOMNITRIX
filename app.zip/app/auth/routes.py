from flask import flash, request, redirect, url_for,render_template
import flask
from flask_login import login_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from . import auth
from app.models import User
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired

users = {}   


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')




@auth.route('/')
def home():
    return '''
        <h1>Welcome to the E-commerce Website</h1>

        <a href="/register">Register</a><br><br>

        <a href="/login">Login</a><br><br>

        <a href="/logout">Logout</a>
    '''

# REGISTER
@auth.route('/register', methods=['GET','POST'])
def register():

    if request.method == 'POST':

        username = request.form.get('username')
        password = request.form.get('password')

        hashed_password = generate_password_hash(password)

        user = User(id=len(users)+1, username=username, password=hashed_password)

        users[username] = user
        
        return render_template("success.html", message="Registration successful! You can now log in.")

    return render_template("register.html")


# LOGIN
@auth.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        
        user = users.get(username)
        
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('auth.home'))
        else:
            flash("Invalid username or password")
    
    return render_template("login.html", form=form)

# LOGOUT
@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.home'))
